package TP_OutilsFormels;

public enum Etat{
    ETAT_INITIAL,
    ACCES_ACCORDE,
    ACCES_REFUSE,
    ALARME_DECLENCHEE
}
