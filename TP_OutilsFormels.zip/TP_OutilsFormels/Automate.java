package TP_OutilsFormels;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Automate {
    private Etat etat;
    private Map<String, Personne> personnes;
    private List<String> historique;

    public Automate() {
        this.etat = Etat.ETAT_INITIAL;
        this.personnes = new HashMap<>();
        this.historique = new ArrayList<>();
    }

    public void enregistrerPersonne(String nom, String codeEntree, String carteAcces) {
        if (personnes.containsKey(carteAcces)) {
            System.out.println("Erreur, cette carte d'accès est déjà utilisée !");
        } else {
            personnes.put(carteAcces, new Personne(nom, codeEntree, carteAcces));
            System.out.println("Personne enregistrée avec succès !");
        }
    }

    public void entrerBatiment(String carteAcces, Scanner scanner) {
        Personne personne = personnes.get(carteAcces);

        if (personne == null) {
            etat = Etat.ACCES_REFUSE;
            System.out.println("\nACCES REFUSE\nCarte invalide !");
            return;
        }

        int essaisRestants = 3;
        while (essaisRestants > 0) {
            System.out.print("Entrer le code d'accès : ");
            String codeValidation = scanner.nextLine();

            if (codeValidation.equals(personne.getCodeEntree())) {
                if (personne.isDansBatiment()) {
                    etat =Etat.ACCES_REFUSE;
                    System.out.println("ACCES REFUSE\n" + personne.getNom() + " est déjà dans le bâtiment !");
                    return;
                }

                etat = Etat.ACCES_ACCORDE;
                personne.entrerDansBatiment();
                String heure = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                historique.add("Entrée : " + personne.getNom() + " à " + heure);
                System.out.println("\nACCES ACCORDE. \nBienvenue, " + personne.getNom() + " !");
                return;
            } else {
                essaisRestants--;
                etat =Etat.ACCES_REFUSE;
                System.out.println("\nACCES REFUSE");
                System.out.println("Votre code incorrect. Essais restants : " + essaisRestants);
            }
        }

        etat = Etat.ALARME_DECLENCHEE;
        System.out.println("\nALARME DECLENCHEE !!");
    }

    public void sortirBatiment(String carteAcces) {
        Personne personne = personnes.get(carteAcces);
        if (personne == null) {
            System.out.println("Erreur, pas d'utilisateur avec cette carte !");
        } else if (!personne.isDansBatiment()) {
            System.out.println("Erreur, " + personne.getNom() + " n'est pas dans le bâtiment !");
        } else {
            personne.sortirDuBatiment();
            String heure = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            historique.add("Sortie : " + personne.getNom() + " à " + heure);
            System.out.println(personne.getNom() + " a quitté le bâtiment.");
        }
    }

    public void afficherHistorique() {
        System.out.println("\n--- Historique de la journée ---");
        if (historique.isEmpty()) {
            System.out.println("Aucune entrée enregistrée aujourd'hui.");
        } else {
            for (String evenement : historique) {
                System.out.println(evenement);
            }
        }
    }
}
