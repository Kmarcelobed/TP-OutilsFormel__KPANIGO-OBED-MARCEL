package TP_OutilsFormels;


import java.util.Scanner;

public class Controle {
    public static void main(String[] args) {
        Automate gestionAcces = new Automate();
        Scanner scanner = new Scanner(System.in);
        boolean continuer = true;

        while (continuer) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Enregistrer une personne");
            System.out.println("2. Entrer dans le bâtiment");
            System.out.println("3. Sortir du bâtiment");
            System.out.println("4. Afficher l'historique de la journée");
            System.out.println("5. Quitter");
            System.out.print("Choisissez une option : ");
            int choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1:
                    System.out.print("Nom : ");
                    String nom = scanner.nextLine();
                    System.out.print("Entrez l'ID de votre carte d'accès : ");
                    String carteAcces = scanner.nextLine();
                    System.out.print("Entrez votre code d'acces : ");
                    String codeEntree = scanner.nextLine();


                    gestionAcces.enregistrerPersonne(nom, codeEntree, carteAcces);
                    break;

                case 2:
                    System.out.print("Scan de la carte d'accès , Entrez votre (ID) : ");
                    String carteID = scanner.nextLine();
                    gestionAcces.entrerBatiment(carteID, scanner);
                    break;

                case 3:
                    System.out.print("Scan de la carte d'accès avant de sortir, Entrez votre (ID) : ");
                    String carteSortie = scanner.nextLine();
                    gestionAcces.sortirBatiment(carteSortie);
                    break;

                case 4:
                    gestionAcces.afficherHistorique();
                    break;

                case 5:
                    continuer = false;
                    System.out.println("Au revoir !");
                    break;

                default:
                    System.out.println("Erreur , Choisir entre 1 et 5");
            }
        }

        scanner.close();
    }
}