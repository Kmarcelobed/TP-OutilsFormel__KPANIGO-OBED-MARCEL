package TP_OutilsFormels;

public class Personne {
    private String nom;
    private String codeEntree;
    private String carteAcces;
    private boolean dansBatiment;

    public Personne(String nom, String codeEntree, String carteAcces) {
        this.nom = nom;
        this.codeEntree = codeEntree;
        this.carteAcces = carteAcces;
        this.dansBatiment = false;
    }

    public String getNom() {
        return nom;
    }

    public String getCodeEntree() {
        return codeEntree;
    }

    public String getCarteAcces() {
        return carteAcces;
    }

    public boolean isDansBatiment() {
        return dansBatiment;
    }

    public void entrerDansBatiment() {
        this.dansBatiment = true;
    }

    public void sortirDuBatiment() {
        this.dansBatiment = false;
    }
}